
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Módulo de Solicitudes</title>
    <link rel="stylesheet" href="estilos.css"> 
</head>
<body>

    <header>
        <h1>Sistema de Soporte Técnico UPQ/h1>

        <nav>
            <a href="index.html">Inicio</a> |
            <a href="usuarios.html">Usuarios</a> |
            <a href="equipos.html">Equipos</a> |
            <a href="solicitudes.html">Solicitudes</a> |
            <a href="seguimiento.php">Seguimiento</a>
        </nav>
    </header>

    <main>

        <section>
            <h2>Registrar solicitud de soporte técnico</h2>

            <form action="guardar_solicitud.php" method="POST">

                <label for="usuario">Usuario solicitante:</label>
                <select id="usuario" name="id_usuario" required>
                    <option value="">Selecciona un usuario</option>
                    <!-- se cargaran los usuarios desde la base de datos -->
                </select>

                <br><br>

                <label for="equipo">Equipo:</label>
                <select id="equipo" name="id_equipo" required>
                    <option value="">Selecciona un equipo</option>
                    <!-- se cargaran los equipos desde la base de datos -->
                </select>

                <br><br>

                <label for="descripcion">Descripción del problema:</label>
                <br>

                <textarea
                    id="descripcion"
                    name="descripcion"
                    rows="5"
                    cols="40"
                    placeholder="Describe el problema que presenta el equipo..."
                    required></textarea>

                <br><br>

                <p>
                    <strong>Estado inicial:</strong> Pendiente
                </p>
                <button type="submit">Registrar solicitud</button>
            </form>
        </section>

        <hr>

        <section>
            <h2>Solicitudes registradas</h2>

            <table>
                <thead>
                    <!-- lista de solicitudes -->
                    <tr>
                        <th>ID</th>
                        <th>Usuario</th>
                        <th>Equipo</th>
                        <th>Descripción del problema</th>
                        <th>Estado</th>
                    </tr>
                </thead>

                <tbody>

                    <?php
                    /* conecta con consulta_mensajes.php */
                    require 'consulta_mensajes.php';
                    /* define mensajes con la funcion de consulta y borrar con la funcion de borrar
                    de sus respectivos codigos */
                    $mensajes = consultamensajes();
                    while ($arrMensaje=mysqli_fetch_array($mensajes)){
                        
                    echo "<tr>
                        <td>".$arrMensaje['id']."</td>
                        <td>".$arrMensaje['nombre']."</td>
                        <td>".$arrMensaje['equipo']."</td>
                        <td>".$arrMensaje['mensaje']."</td>
                        <td>".$arrMensaje['estado']."</td>
                    </tr>";
                    }
                    ?>

                </tbody>
            </table>
        </section>

    </main>

    <footer>
        <p>Sistema de Soporte Técnico Universitario</p>
    </footer>

</body>
</html>